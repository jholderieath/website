#' @rdname WildPigABM
#' @export
generateAndPassPV <- function(map_height,map_width,total_patches,
                              ...){
  initialPatchVarArray <- array(data=0,c(map_height, map_width,8))
  dimnames(initialPatchVarArray) <- list(paste("height",1:map_height,sep = ""),
                           paste("width",1:map_width,sep = ""),
                           c("quality","effect_comm","effect_free","effect_govt","effect_fee","memory","patch_id","psi_lastPeriod"))
  
  # generate quality variable for each patch
  initialPatchVarArray[,,'quality']       <- array(data = stats::runif(total_patches, min = 0.5, max = (1.5)),c(map_height, map_width))
  # generate effect_comm variable for each patch
  #initialPatchVarArray[,,'effect_comm']   <- array(data = stats::runif(total_patches, min = 0.5, max = (1 + 2.220e-16)),c(map_height, map_width)) 
  # generate effect_free variable for each patch
  #initialPatchVarArray[,,'effect_free']   <- array(data = stats::runif(total_patches, min = 0.5, max = (1 + 2.220e-16)),c(map_height, map_width)) 
  # generate effect_govt variable for each patch
  #initialPatchVarArray[,,'effect_govt']   <- array(data = stats::runif(total_patches, min = 0.5, max = (1 + 2.220e-16)),c(map_height, map_width)) 
  # generate effect_fee variable for each patch
  #initialPatchVarArray[,,'effect_fee']    <- array(data = stats::runif(total_patches, min = 0.9, max = (1 + 2.220e-16)),c(map_height, map_width)) 
  # generate memory variable for each patch
  #initialPatchVarArray[,,'memory']        <- array(data = stats::runif(total_patches, min = -0.25, max = -.01),c(map_height, map_width)) 
  # generate patch_id variable for each patch
  initialPatchVarArray[,,'patch_id']       <- array(data = 1:(total_patches), c(map_height, map_width)) 
  # generate initial psi_t-1 variable for each patch
  initialPatchVarArray[,,'psi_lastPeriod'] <- array(data = 2.220e-16, c(map_height, map_width)) 
  

  NL_pushToMap("quality",initialPatchVarArray[,,'quality'],nl.obj = NULL)
  #NL_pushToMap("effect_comm",initialPatchVarArray[,,'effect_comm'],nl.obj = NULL)
  #NL_pushToMap("effect_free",initialPatchVarArray[,,'effect_free'],nl.obj = NULL)
  #NL_pushToMap("effect_govt",initialPatchVarArray[,,'effect_govt'],nl.obj = NULL)
  #NL_pushToMap("effect_fee",initialPatchVarArray[,,'effect_fee'],nl.obj = NULL)
  #NL_pushToMap("memory",initialPatchVarArray[,,'memory'] ,nl.obj = NULL)
  NL_pushToMap("patch_id", initialPatchVarArray[,,'patch_id'],nl.obj = NULL)
  NL_pushToMap("psi_lastPeriod",initialPatchVarArray[,,'psi_lastPeriod'] ,nl.obj = NULL)
  
  #allow
  # RNetLogo::NLSetPatches('allowFee',allow[,,'fee'])
  # RNetLogo::NLSetPatches('allowFree',allow[,,"free"])
  # RNetLogo::NLSetPatches('allowPro',allow[,,'pro'])
  #varcost
  # vca <- array(data=0,c(map_height, map_width,6))
  # dimnames(vca) <- list(paste("height",1:map_height,sep = ""),
  #                       paste("width",1:map_width,sep = ""),
  #                       c("Corn","Soy","CRP","SellPaid","Free","PayPaid"))
  # vca[,,'Corn']     <- array(data = varCost_corn, c(map_height, map_width))
  # vca[,,'Soy']      <- array(data = varCost_soy, c(map_height, map_width))
  # vca[,,'CRP']      <- array(data = verCost_CRP, c(map_height, map_width))
  # RNetLogo::NLSetPatches('varCost_corn',vca[,,'Corn']) 
  # RNetLogo::NLSetPatches('varCost_soy',vca[,,'Soy'] )
  # RNetLogo::NLSetPatches('verCost_CRP',vca[,,'CRP'])
  # update Prices--------------------------------------------------------------------------
  # prices <- array(data=0,c(map_height, map_width,6))
  # dimnames(prices) <- list(paste("height",1:map_height,sep = ""),
  #                          paste("width",1:map_width,sep = ""),
  #                          c("pCorn","pSoy","pCRP","pSellPaid","pFree","pPayPaid"))
  # prices[,,'pCorn']     <- array(data = P_corn, c(map_height, map_width))
  # prices[,,'pSoy']      <- array(data = P_soy, c(map_height, map_width))
  # prices[,,'pCRP']      <- array(data = P_CRP, c(map_height, map_width))
  # RNetLogo::NLSetPatches('P_corn',prices[,,'pCorn'])
  # RNetLogo::NLSetPatches('P_soy',prices[,,'pSoy'] )
  # RNetLogo::NLSetPatches('P_CRP',prices[,,'pCRP'])
  # create yield matrices----------------------------------------------------------
  # yield<-array(data=0,c(map_height, map_width,3))
  # dimnames(yield) <- list(paste("height",1:map_height,sep = ""),
  #                         paste("width",1:map_width,sep = ""),
  #                         c("Yield_corn","Yield_soy","Yield_CRP"))
  # yield[,,'Yield_corn']    <- matrix(data=Yield_corn,nrow=map_height,ncol=map_width)
  # yield[,,'Yield_soy']    <- matrix(data=Yield_soy,nrow=map_height,ncol=map_width)
  # yield[,,'Yield_CRP']    <- matrix(data=patchSize,nrow=map_height,ncol=map_width)
  # RNetLogo::NLSetPatches('Yield_corn',yield[,,'Yield_corn']) 
  # RNetLogo::NLSetPatches('Yield_soy',yield[,,'Yield_soy'])
  # RNetLogo::NLSetPatches('Yield_CRP',yield[,,'Yield_CRP'])
  # send time requirement to NL
  # time <- array(0,c(map_height,map_width,6))
  # dimnames(time) <- list(paste('height',1:map_height,sep = ""),
  #                        paste('width',1:map_width,sep = ""),
  #                        c('corn','soy','CRP','FEEPAYING',
  #                          'UNPAIDPRES','PAIDREMOVAL'))
  # time[,,'corn'] <- array(data = t_corn, c(map_height,map_width))
  # time[,,'soy'] <- array(data = t_soy, c(map_height,map_width))
  # time[,,'CRP'] <- array(data = t_CRP, c(map_height,map_width))
  # RNetLogo::NLSetPatches('t_soy',time[,,'soy']) 
  # RNetLogo::NLSetPatches('t_corn',time[,,'corn'])
  # RNetLogo::NLSetPatches('t_CRP',time[,,'CRP'])

  
  
  return(initialPatchVarArray)
}