## Seed Initial FS ------------------------------------------------------------
#seed sexed pigs
#' @rdname WildPigABM
NL_seedBoarsAndSounders <- function(verboseR, ...){
  RNetLogo::NLCommand('setup-boars')
  RNetLogo::NLCommand('setup-sows')
  if (verboseR == TRUE) {print("FS seeded!")}
}

# countSounders() count pigs in NL --------------------------
#' @rdname WildPigABM
countSounders <- function(verboseR, map_height, map_width,...) {
  RNetLogo::NLCommand('countSows')
  if (verboseR == TRUE) {print("sounders counted and added")}
  array(data = RNetLogo::NLGetPatches('sowCount',
                                      as.data.frame = FALSE,
                                      as.matrix = TRUE), c(map_height, map_width))
  
}
# countBoars() count pigs in NL --------------------------
#' @rdname WildPigABM
countBoars <- function(verboseR, map_height, map_width,...) {
  RNetLogo::NLCommand('countBoars')# count patches with pigs etc
  if (verboseR == TRUE) {print("boars Counted")}
  array(data = RNetLogo::NLGetPatches("boarCount",
                                      as.data.frame = FALSE,
                                      as.matrix = TRUE), c(map_height, map_width))
 
}



## pigspresent() - function takes array created by countPigs and creates a binary matrix inidcating presence -------
#' @rdname WildPigABM
pigsPresent <- function(verboseR, map_height, map_width,...) {
  sounderCountArray <- countSounders(verboseR, map_height, map_width)
  boarCountArray <- countBoars(verboseR, map_height, map_width)
  absence = sounderCountArray + boarCountArray 
  absence[, ][which(absence[, ] == 0)] = -1
  absence[, ][which(absence[, ] > 0)] = -2
  absence[, ][absence[, ] == -1] <- as.numeric(0)
  absence[, ][absence[, ] == -2] <- as.numeric(1)
  array(data = absence, c(map_height, map_width))
}
  



#' @rdname WildPigABM
breedR <- function(verboseR,psi_lastPeriod,...){
  RNetLogo::NLCommand('breedR')
  if (verboseR == TRUE) {print("pigs reproduced")}
}
## cageyPigs() - update FS cageyness --------------------------------------------
# Follow up function needs cleaned up; many duplicate actions; would be better off to go patch by patch
 

#' @rdname WildPigABM
cageyPigs <- function(verboseR,...){
  RNetLogo::NLCommand('scarePigs')
  s <- RNetLogo::NLGetAgentSet(
    c("mypsi", "scagey"), 
    "sows", as.data.frame=TRUE)
  cs <- s$scagey
  ms <- s$mypsi
  x <- cs/2 + ms
  normalized = (x-min(x))/(max(x)-min(x) + 2.22e-16)
  RNetLogo::NLSetAgentSet('sows', normalized, 'scagey')
  
  b <- RNetLogo::NLGetAgentSet(
    c("mypsi", "bcagey"), 
    "boars", as.data.frame=TRUE)
  x <- ((b$bcagey / 2) + b$mypsi)
  normalized = (x-min(x))/(max(x)-min(x) + 2.22e-16)
  RNetLogo::NLSetAgentSet('boars', normalized, 'bcagey')
                                                   
  if (verboseR == TRUE) {print("pigs cagey update")}
} 



## merge and split sounders ---------------------------------------------------
# sets probability for merge and split, then does it
#' @rdname WildPigABM
sounderMergeAndSplit <- function(verboseR,...){
  RNetLogo::NLCommand('searchForSimilar')
  RNetLogo::NLCommand('splitTheSounder')
  RNetLogo::NLCommand('splitSmallSounders')
  RNetLogo::NLCommand('gatherTheLonely')
  if (verboseR == TRUE) {print("FS merged and split!")}
}

## calculate desirability of patches to FS ------------------------------------
#' @rdname WildPigABM
prepareToMove <- function(verboseR, map_height, map_width, max_pigs, allowableOverCap,
                          total_patches, psi_lastPeriod, quality, unit_mat,epsilon_mat, ...){
  x <- RNetLogo::NLGetPatches("normalizedPatchAttractivenessPriortoLandClaim",
                              patchset="patches", as.matrix=TRUE, 
                              as.data.frame=FALSE, patches.by.row=FALSE,
                              as.vector=FALSE, nl.obj=NULL)
  y <- normalize(x)
  RNetLogo::NLSetPatches("normalizedPatchAttractivenessPriortoLandClaim", 
                         y, nl.obj = NULL)#push to map
  # establish land-claims
RNetLogo::NLCommand('countFSTerritoryStrength')
}

## movement of pigs --------------------------------------------
#move sounders
#' @rdname WildPigABM
moveSounders <- function(...){
# find who claimed, turn my claims to zero, incorporate into sounder preferences, move a sounder at random
RNetLogo::NLCommand('moveSows')
}
#move boars
#' @rdname WildPigABM
moveBoars <- function(...){
  # incorporate land claims into boar's preferences and move a boar at random
  RNetLogo::NLCommand('moveBoars')
}

# damage for sexed pigs -------------------------------------------------
#' @rdname WildPigABM
cropDamageIntensity <- function(verboseR, map_height, map_width, max_pigs, total_patches,...){
  sounderclaim <- sounderLandClaim(verboseR,map_height, map_width)
  boarclaim <- boarLandClaim(verboseR,map_height,map_width)
  x <- sounderclaim + boarclaim
  normalized = (x-min(x))/(max(x)-min(x) + 2.22e-16)
  if (verboseR == TRUE) {print("crop damage intensity!")}
  if (verboseR == TRUE) {print(normalized)}
  return(normalized)
}

# Removal for boars ----------------------------
#' @rdname WildPigABM
goRemoveBoarsandSows <- function(verboseR,...){
  RNetLogo::NLCommand('setPrRemoved')
  x <- RNetLogo::NLGetAgentSet(
    "prRemoved", 
    "boars", as.data.frame=TRUE)
  normalized = (x-min(x))/(max(x)-min(x) + 2.22e-16)
  RNetLogo::NLSetAgentSet('boars', normalized, 'prRemoved')
  x <- RNetLogo::NLGetAgentSet(
    "prRemoved", 
    "sows", as.data.frame=TRUE) 
  normalized = (x-min(x))/(max(x)-min(x) + 2.22e-16)
  RNetLogo::NLSetAgentSet('sows', normalized, 'prRemoved')
  RNetLogo::NLCommand('goRemoveBoars')
  RNetLogo::NLCommand('goRemoveSounders')
  if (verboseR == TRUE) {print("pigs removed!")}
}


# Count the Dead --------------
#' @rdname WildPigABM
#' @export
countDead <- function(verboseR,...){
  RNetLogo::NLCommand('countDead')
  c <- RNetLogo::NLReport("killed-count")
  if (verboseR == TRUE) {print("dead counted!")}
  return(c)
}

# kill the dead; clean up. reset land  ----------------------------
#' @rdname WildPigABM
goKillthedead <- function(verboseR,...){
  RNetLogo::NLCommand('killTheDead')
  if (verboseR == TRUE) {print("The dead have been killed!")}
}

##==================== REWRITE =====================================



# DO I NEED A RELIEF VALVE ON FS POPULATION?
# to go-overpop
# ask patches[
#   set pigcensus count pigs-here
#   ]
# let pigpop-list [pigcensus] of patches
# let pigpop sum pigpop-list
# let overpop max list 0 (pigpop - max_pigs)
# 
# 
# if overpop > 0 [
#   ask n-of overpop pigs [
#     hatch-dead 1 [ht]
#     die
#     ]
#   ]
# 
# set dead-list [age] of dead
# set dead-count count dead
# set dead-mean ifelse-value empty? dead-list ['na'] [mean dead-list]
# end