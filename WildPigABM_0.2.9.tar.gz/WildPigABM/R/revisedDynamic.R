#' @rdname WildPigABM
#' @export
removalPrice <- function(x){
  35.404 + (1464)/(1 + (x/3.299004)^1.843566)
}

#' @rdname WildPigABM
#' @export
pctDamFunc <- function(x){ 0.9 + (-0.899)/(1 + (x/14.21)^5)}

#' @rdname WildPigABM
#' @export
incrRemovalPrice <- function(x,y,...){
sum(removalPrice(x:y))  
}

#' @rdname WildPigABM
#' @export
minusUserCost <- function(pop_if_none,pop_if,...){
  x <- pop_if_none
  y <- pop_if
  z = x-y
  (userCostf(y)-userCostf(x))*z
}


#' @rdname WildPigABM
#' @export
estGM <- function(pop_if_none, pop_if_light, pop_if_heavy ,
                  dam_corn,dam_soy,dam_crp,
                  adjYieldCorn, adjYieldSoy,
                  P_corn, p_soy, p_crp,
                  varCost_corn,varCost_soy,varCost_crp,
                  dFnForm,Removal_Price,User_Cost,...){
  P_crp=P_CRP
  varCost_crp=verCost_CRP
  adjYieldCRP=10
# linDam <- ifelse(dFnForm=="linear",1,0)
# SigDam <- ifelse(dFnForm=="sigmoidal",1,0)
linear <- ifelse(Removal_Price=="linear",1,0)
marginal <- ifelse(Removal_Price=="marginal",1,0)
minus <- ifelse(Removal_Price=="minus",1,0)
ucminus <- ifelse(User_Cost=="minus",1,0)
ucmyopic <- 0
uclinear <- ifelse(User_Cost=="linear",1,0)

 
K = list("Corn","Soy","CRP")
KK = list("none","light","heavy")
for (k in 1:length(K)){
  for (kk in 1:length(KK)){
    p<-get(paste0("P_",tolower(K[[k]])))
    y<-get(paste0("adjYield",K[[k]]))
    d<-get(paste0("pop_if_",KK[[kk]]))
    vc<-get(paste0("varCost_",tolower(K[[k]])))
    
    gm <- p*(y-y*pctDamFunc(d))-vc-   #Net Income
      linear*(removalPrice(d)*(pop_if_none-d)) - # linear removal pricing
      marginal*(incrRemovalPrice(pop_if_none,d))- # removal price evaluated at each animal removed
      minus*((removalPrice(d)-removalPrice(pop_if_none))*(pop_if_none-d))+ #removal price is difference of evaluated price times removed animals
      ucminus*(minusUserCost(pop_if_none,d))-
      ucmyopic*(d)-
      uclinear*(userCostf(d)*(pop_if_none-d))
    
    nam <- paste0("gm_",tolower(K[[k]]),"_",KK[[kk]])
    
    assign(nam,gm)
  }
}
return(c(gm_corn_none,
         gm_corn_light,
         gm_corn_heavy,
         gm_soy_none,
         gm_soy_light,
         gm_soy_heavy,
         gm_crp_none,
         gm_crp_light,
         gm_crp_heavy ))
}



#============================================================================
# All of the landowner decision making functions use the same framework.  
# The only difference is the forumulation of the objective function.
# The revised dynamicish function realizes this and provides flexibility for 
# mixed levels of rationality.

#' @rdname WildPigABM
#' @export
RevisedDynamicISH <- function(verboseR, t, now,today,
                       init_hh,
                       P_corn,P_soy,P_CRP,
                       varCost_corn, varCost_soy,verCost_CRP,
                       removalPrFnVec,userCostFnVec,typeDecision,
                       ...) {
    ## NL has all it needs
    RNetLogo::NLCommand('dynamic-prep-step1')
    Sys.sleep(2)
    landownersolution <- list()
    #start looping
    for (j in 1:init_hh) {
      hh <- j - 1
      if (verboseR == TRUE) {print(paste("hh=", hh))}
      patchset <- paste("patches with [owner = ",hh,"]")
      dat <- RNetLogo::NLGetPatches(c(
        "pxcor", "pycor",'pop_if_none',
        'pop_if_light',
        'pop_if_heavy',
        'adjYieldCorn',
        'adjYieldSoy',
        "pigTerritoryStrength"),
        patchset)
      Sys.sleep(2)
      
      pigTerritoryStrength <- as.vector(dat$pigTerritoryStrength)
      pop_if_none <- as.vector(dat$pop_if_none)
      pop_if_light <- as.vector(dat$pop_if_light)
      pop_if_heavy <- as.vector(dat$pop_if_heavy)
      adjYieldCorn <- as.vector(dat$adjYieldCorn)
      adjYieldSoy <- as.vector(dat$adjYieldSoy)
      
      #========== eval marginal cost at current, and cost at proposed population subtract 
      #fun.6
      #usercost
      #f
      #set gross margins
      
      obj <- estGM(pop_if_none=pop_if_none, 
                   pop_if_light=pop_if_light, 
                   pop_if_heavy=pop_if_heavy,
                   dam_corn=dam_Corn,
                   dam_soy=dam_soy,
                   dam_crp=dam_CRP,
                   adjYieldCorn=adjYieldCorn, 
                   adjYieldSoy=adjYieldSoy,
                   P_corn=P_corn, 
                   P_soy=P_soy, 
                   P_crp=P_CRP,
                   varCost_corn=varCost_corn,
                   varCost_soy=varCost_soy,
                   varCost_crp=verCost_CRP,
                   dFnForm=NULL,
                   Removal_Price=removalPrFnVec[j],
                   User_Cost=userCostFnVec[j])
      pc <- nrow(dat)
      
      #Build patch use restriction matrix
      #Looks like [I|I...]
      pu  <- cbind(
        diag(pc),
        diag(pc),
        diag(pc),
        
        diag(pc),
        diag(pc),
        diag(pc),
        
        diag(pc),
        diag(pc),
        diag(pc))
      #Overkill at this point, previous versions needed to put together many submatrices
      #into a single large matrix
      mat <- rbind(pu)
      #RHS is all 1s
      rhs <- c(rep_len(1,  length.out = pc))
      #all eq. are stated as <=
      dir <- c(rep_len('<=', length.out = pc))
      #all choice variables are continuious
      types <- c(rep_len('C', length.out = pc * 9))
      
      indd <- c(1:(pc * 9))
      bounds <- list(lower = list(ind=indd,val=c(rep_len(0, length.out = (pc * 9)))),
                     upper = list(ind=indd,val=c(rep_len(1, length.out = (pc * 9))))
      )
      
      soln <- Rglpk::Rglpk_solve_LP(obj, mat=mat, dir, rhs, 
                                    bounds = bounds, 
                                    types = types,
                                    max = TRUE, 
                                    control = 
                                      list("presolve" = TRUE,
                                           "tm_limit" = 120000,
                                           verbose = TRUE,
                                           canonicalize_status = FALSE))
      solution <- soln$solution
      optimum <- soln$optimum
      status <- soln$status 
      spaceFrom <- seq(1,pc*8+1,pc)
      spaceTo <- seq(pc,pc*9,pc)
      Sys.sleep(1)
      
      dat$a_corn_none <- solution[spaceFrom[1]:spaceTo[1]]
      myvars <- c("pxcor", "pycor", "a_corn_none")
      
      transfer <- dat[myvars]
      RNetLogo::NLSetPatchSet('a_corn_none',transfer)
      Sys.sleep(1)
      
      dat$a_corn_light <- solution[spaceFrom[1]:spaceTo[1]]
      transfer <- dat[c("pxcor","pycor","a_corn_light")]
      RNetLogo::NLSetPatchSet('a_corn_light',transfer)
      Sys.sleep(1)
      
      dat$a_corn_heavy <- solution[spaceFrom[2]:spaceTo[2]]
      transfer <- dat[c("pxcor","pycor","a_corn_heavy")]
      RNetLogo::NLSetPatchSet('a_corn_heavy',transfer)
      Sys.sleep(1)
      
      dat$a_soy_none <- solution[spaceFrom[3]:spaceTo[3]]
      transfer <- dat[c("pxcor","pycor","a_soy_none")]
      RNetLogo::NLSetPatchSet('a_soy_none',transfer)
      Sys.sleep(1)
      
      dat$a_soy_light <- solution[spaceFrom[4]:spaceTo[4]]
      transfer <- dat[c("pxcor","pycor","a_soy_light")]
      RNetLogo::NLSetPatchSet('a_soy_light',transfer)
      Sys.sleep(1)
      
      dat$a_soy_heavy <- solution[spaceFrom[5]:spaceTo[5]]
      transfer <- dat[c("pxcor","pycor","a_soy_heavy")]
      RNetLogo::NLSetPatchSet('a_soy_heavy',transfer)
      Sys.sleep(1)
      
      dat$a_CRP_none <- solution[spaceFrom[6]:spaceTo[6]]
      transfer <- dat[c("pxcor","pycor","a_CRP_none")]
      RNetLogo::NLSetPatchSet('a_CRP_none',transfer)
      Sys.sleep(1)
      
      dat$a_CRP_light <- solution[spaceFrom[7]:spaceTo[7]]
      transfer <- dat[c("pxcor","pycor","a_CRP_light")]
      RNetLogo::NLSetPatchSet('a_CRP_light',transfer)
      Sys.sleep(1)
      
      dat$a_CRP_heavy <- solution[spaceFrom[8]:spaceTo[8]]
      transfer <- dat[c("pxcor","pycor","a_CRP_heavy")]
      RNetLogo::NLSetPatchSet('a_CRP_heavy',transfer)
      Sys.sleep(1)
      
      
      
      if (verboseR == TRUE) {print(paste("LU pushed in period", t, "for HH",j))}
      print(dim(list))
      print(dim(solution))
      print(dim(optimum))
      print(dim(status))
      print(dim(obj))
      print(dim(mat))
      print(dim(dir))
      print(dim(rhs))
      
      
      landownersolution[j] <- list(solution=solution,
                                   dat=dat,
                                   optimum=optimum, 
                                   status=status, 
                                   obj=obj, 
                                   mat=mat, 
                                   dir=dir, 
                                   rhs=rhs)
    }
    mainDir <- "C:/Users/zejas/OneDrive - Colostate/DissertationTopics/ABM/Intermediate_output/"
    subDir <- format(today, format="%Y%b%d")
    dirc <- paste(mainDir,subDir,"/",sep = "")
    dir.create(file.path(dirc), showWarnings = FALSE, recursive = FALSE)
    nam <- paste(dirc,"decisionReturn",t,j,"_",typeDecision,".rda", sep = "")
    save(landownersolution,file = nam)
    return(landownersolution)
  }