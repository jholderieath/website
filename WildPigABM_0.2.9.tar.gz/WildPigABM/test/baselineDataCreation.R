gui = TRUE
generic_removal_price = 35



Govt_ON = FALSE
multiYearLand = FALSE
stochastic = FALSE
cont = FALSE
typeInformation = NULL

discount <- 0.05
allow_Fee_Hunting = TRUE
allow_free_hunting = TRUE
allow_pro_removal = TRUE
sdMult <- ifelse(stochastic == TRUE,sdMult,0)
allowableOverCap = msm::rtnorm(1, mean=10, sd=1*sdMult, lower=0, upper=Inf)
# sets allowable over capacity per patch max pigs per# patch is max_pigs * allowableOverCap / total_patches
allow <- array(data=0,c(map_height,map_width,3))
dimnames(allow) <- list(paste("height",1:map_height,sep = ""),
                        paste("width",1:map_width,sep = ""),
                        c("fee","free","pro"))
allow[,,'fee'] = array(data = ifelse(allow_Fee_Hunting == TRUE, 1, 0),
                       c(map_height,map_width))
allow[,,'free'] = array(data = ifelse(allow_free_hunting == TRUE, 1, 0),
                        c(map_height,map_width))
allow[,,'pro'] = array(data = ifelse(allow_pro_removal == TRUE, 1, 0),
                       c(map_height,map_width))
brange = msm::rtnorm(1, mean=5, sd=1*sdMult, lower=0, upper=50)
boarTerritoryDecay = msm::rtnorm(1, mean= 1, sd=1*sdMult, lower=0, upper=2)
dam_CRP = 0
dam_Corn = msm::rtnorm(1, mean= 0.02365, sd=1*sdMult, lower=0, upper=1)
dam_soy = msm::rtnorm(1, mean= 0.01715, sd=1*sdMult, lower=0, upper=1)
defaultLitter = msm::rtnorm(1, mean= 0.8, sd=1*sdMult, lower=0, upper=1)
effect_comm =  msm::rtnorm(1, mean=.9, sd=1*sdMult, lower=0, upper=1)
effect_fee =   msm::rtnorm(1, mean=.8, sd=1*sdMult, lower=0, upper=1)
effect_free =  msm::rtnorm(1, mean=.65, sd=1*sdMult, lower=0, upper=1)
effect_govt =  msm::rtnorm(1, mean=.9, sd=1*sdMult, lower=0, upper=1)
EGM_offFarm = msm::rtnorm(1, mean= 100, sd=1*sdMult, lower=1, upper=500)
gov_budget = msm::rtnorm(1, mean=100000, sd=1*sdMult, lower=0, upper=Inf)
govLuck = msm::rtnorm(1, mean=0.9, sd=1*sdMult, lower=0.8, upper=1)
init_pigs =  msm::rtnorm(1, mean=100, sd=1*sdMult, lower=0, upper=Inf)
maxSounderN = msm::rtnorm(1, mean=100, sd=1*sdMult, lower=0, upper=Inf)  
mergeAccelerator = msm::rtnorm(1, mean= .25, sd=1*sdMult, lower=0, upper=1)  
mergedistance = msm::rtnorm(1, mean=100, sd=1*sdMult, lower=0, upper=Inf)# maximum merge distance
minPigsFee =  msm::rtnorm(1, mean=10, sd=1*sdMult, lower=0, upper=Inf)
minSounderN = msm::rtnorm(1, mean=4, sd=1*sdMult, lower=0, upper=Inf)
P_corn =  msm::rtnorm(1, mean=3.71, sd=1*sdMult, lower=0, upper=Inf)
P_CRP = msm::rtnorm(1, mean=100, sd=500*sdMult, lower=0, upper=Inf)
P_feePaying = msm::rtnorm(1, mean=300, sd=1*sdMult, lower=0, upper=Inf)
govRemovalPrice = msm::rtnorm(1, mean=65, sd=1*sdMult, lower=0, upper=Inf)
P_soy =  msm::rtnorm(1, mean=9.15, sd=1*sdMult, lower=0, upper=Inf)
pig_range = msm::rtnorm(1, mean=10, sd=1*sdMult, lower=0, upper=Inf)
sexRatio = msm::rtnorm(1, mean= .25, sd=1*sdMult, lower=0, upper=1)# males to total pop
SounderterritoryDecay = msm::rtnorm(1, mean= 1, sd=1*sdMult, lower=0, upper=2)
splitAccelerator = msm::rtnorm(1, mean= .25, sd=1*sdMult, lower=0, upper=1)
srange = msm::rtnorm(1, mean=5, sd=1*sdMult, lower=0, upper=50)
wealth =  msm::rtnorm(1, mean=500000, sd=1*sdMult, lower=0, upper=Inf)

competingWildlife	=	 FALSE
cont	=	 FALSE
dam_CRP	=	0
Govt_ON	=	 TRUE

init_hh	=	45
map_height	=	49
map_width	=	49
max_cycles	=	10
max_pigs	=	1440
multiYearLand	=	 TRUE
num_choice	=	12
patchSize	=	10
solver	=	 NULL
stochastic	=	 TRUE
stochastic	=	 FALSE
swf	=	1
t_corn	=	0.5
t_CRP	=	2.22E-16
t_FEEPAYING	=	1
t_offfarm	=	1
t_PAIDREMOVAL	=	2.22E-16
t_soy	=	0.5
t_UNPAIDNOT	=	2.22E-16
t_UNPAIDPRES	=	1
varCost_corn	=	3740
varCost_Fee	=	100
varCost_free	=	2.22E-16
varCost_offFarm	=	2.22E-16
varCost_Paid	=	65
varCost_soy	=	2360
verboseR	=	TRUE
verCost_CRP	=	2.22E-16
Yield_corn	=	1350
Yield_soy	=	450

#windows
dirc <- "C:/Users/zejas/Documents/GitHub/Version 2/WildPigABM/inst/examples/output"
model.path = "C:/Users/zejas/Documents/GitHub/Version 2/FromR_1.0.nlogo"
nl.path <- Sys.getenv("NETLOGO_PATH", "C:/Program Files/NetLogo 5.3.1/app")

BaseLine <- data.frame(
  allowableOverCap 	,
  boarTerritoryDecay 	,
  brange 	,
  competingWildlife 	,
  cont 	,
  dam_Corn 	,
  dam_CRP 	,
  dam_soy 	,
  defaultLitter 	,
  dirc 	,
  discount,
  effect_comm 	,
  effect_fee 	,
  effect_free 	,
  effect_govt 	,
  EGM_offFarm 	,
  generic_removal_price,
  gov_budget 	,
  govLuck 	,
  govRemovalPrice,
  Govt_ON 	,
  init_hh 	,
  init_pigs 	,
  map_height 	,
  map_width 	,
  max_cycles 	,
  max_pigs 	,
  maxSounderN 	,
  mergeAccelerator 	,
  mergedistance 	,
  minPigsFee 	,
  minSounderN 	,
  multiYearLand 	,
  nl.path 	,
  num_choice 	,
  P_corn 	,
  P_CRP 	,
  P_feePaying 	,
  P_soy 	,
  patchSize 	,
  pig_range 	,
  sdMult 	,
  sexRatio 	,
  SounderterritoryDecay 	,
  splitAccelerator 	,
  srange 	,
  stochastic 	,
  swf 	,
  t_corn 	,
  t_CRP 	,
  t_FEEPAYING 	,
  t_offfarm 	,
  t_PAIDREMOVAL 	,
  t_soy 	,
  t_UNPAIDNOT 	,
  t_UNPAIDPRES 	,
  varCost_corn 	,
  varCost_Fee 	,
  varCost_free 	,
  varCost_offFarm 	,
  varCost_Paid 	,
  varCost_soy 	,
  verboseR 	,
  verCost_CRP 	,
  wealth 	,
  Yield_corn 	,
  Yield_soy
)
devtools::use_data(BaseLine,pkg = "WildPigABM",internal = TRUE)
