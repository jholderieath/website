from <- matrix(data=paste("p",1:49,sep = ""),nrow = 2401,ncol=1)
to <- matrix(data = rep_len(paste("p",1,sep = ""),49),nrow = 49,ncol=1)
for (i in 2:49){

  to <- rbind(to,matrix(data = rep_len(paste("p",i,sep = ""),49),nrow = 49,ncol=1))
  print(i)
}


rc <- yield_c$rc
frc<- matrix(data = rc,nrow = 2401,ncol = 1)

trc <- matrix(data = rep_len(rc[[1]],49),nrow = 49,ncol=1)
for (i in 2:49){
  trc <- rbind(trc,matrix(data = rep_len(rc[[i]],49),nrow = 49,ncol=1))
  print(i)
}


fr <- yield_c$X1
fc <- yield_c$X2
frcs <- cbind(matrix(data = fr,nrow = 2401,ncol=1),
              matrix(data = fc,nrow = 2401,ncol=1))

trcs <- cbind(matrix(data = fr[1],nrow = 49,ncol=1),
              matrix(data = fc[1],nrow = 49,ncol=1))
for (i in 2:49){
  trcs <- rbind(trcs,cbind(matrix(data = rep_len(fr[[i]],49),nrow = 49,ncol=1),
                           matrix(data = rep_len(fc[[i]],49),nrow = 49,ncol=1)))
  print(i)
}
fromto <- cbind(from,frc,to,trc,frcs,trcs)
fromto <- as.data.frame(fromto)

fromto$ft <- paste(fromto$V1,fromto$V3,sep = "_")
fromto$ed <- sqrt((as.numeric(as.character(fromto$V5))-
                    as.numeric(as.character(fromto$V7)))^2+
                  (as.numeric(as.character(fromto$V6))-
                     as.numeric(as.character(fromto$V8)))^2)
fromto <- plyr::rename(fromto,c("V1"="name","V3"="n2"))
fromto$V5 <- fromto$V6 <- fromto$V7 <- fromto$V8 <- fromto$V2 <-fromto$V4<- NULL
fromto$n2 <- paste("p",fromto$n2,sep = "")
fromto$name <- paste(".",fromto$name,sep = "")
fromto$n2 <- paste(".",fromto$n2,sep = "")
fromto <- fromto[c(3,1,2,4)]

write.csv(fromto,file = "~/gamsdir/projdir/gdist2.csv",append = FALSE )
