c <- matrix(data = runif(49),nrow=7,ncol=7)
cd <- as.matrix(dist(c,method = "euclidean",upper = TRUE))
cdinv <- 1/(cd+2.22e-16)

quality <- matrix(data = c(0.55,0.88	,0.55	,1.45	,0.51	,0.84	,0.52	,0.84	,1.28	,0.54	,1.3	,0.77	,1.36	,1.35	,1.33	,0.53	,0.92	,1.27	,0.6	,1.19	,0.7	,0.97	,0.52	,0.67	,0.97	,0.71	,0.51	,0.57	,0.51	,0.94	,1.1	,0.56	,1.13	,1.32	,1.37	,0.68	,1.02	,1.39	,1.39	,1.26	,1.01	,1.08	,1.39	,0.66	,1.41	,0.75	,1.27	,0.83	,0.79),nrow = 7, ncol = 7)
qdist <- quality*cdinv
qdr <- melt(as.matrix(reshape::rescaler(reshape::rescaler(qdist,type="rank"),"range")))
qdr$rc <- paste("row",as.character(qdr$X1),".col",as.character(qdr$X2),sep = "")
qdr<- plyr::rename(qdr,c("value"=".qdr"))

yield_c <-  melt(as.matrix(Yield_corn * quality))
yield_c$rc <- paste("row",as.character(yield_c$X1),".col",as.character(yield_c$X2),sep = "")
yield_c <- plyr::rename(yield_c,c("value"=".qyc"))

yield_s <-  melt(as.matrix(Yield_soy * quality))
yield_s$rc <- paste("row",as.character(yield_s$X1),".col",as.character(yield_s$X2),sep = "")
yield_s <-  plyr::rename(yield_s,c("value"=".qys"))

yield_crp <-  melt(as.matrix(quality * 10))
yield_crp$rc <- paste("row",as.character(yield_crp$X1),".col",as.character(yield_crp$X2),sep = "")
yield_crp <- plyr::rename(yield_crp,c("value"=".qycrp"))

dfs <- list(qdr,yield_c,yield_s,yield_crp)
gams <- plyr::join_all(dfs,type="full")

gams$X1 <- gams$X2 <- NULL
gams <- gams[c(2,1,3,4,5)]

write.csv(gams,file = "~/gamsdir/projdir/gams.csv" )
